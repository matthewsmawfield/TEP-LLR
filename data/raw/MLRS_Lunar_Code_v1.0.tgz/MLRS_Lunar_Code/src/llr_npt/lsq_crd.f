	SUBROUTINE LSQ(X,Y,NIN,MODE,SIGMULT,A,B,C,SD,SE,
     &		skew,kurtosis,PmM,NREJ)
	IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      INCLUDE 'LICENSE-BSD3.inc'
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C  Thu Oct 20, 1988 16:17:11
C     1) REPLACE "COMPILER DOUBLE PRECISION" WITH
C        "IMPLICIT DOUBLE PRECISION (A-H,O-Z)".
C     2) CHANGE OPTIONAL COMPILE STATEMENTS TO COMMENTS.
C     3) REMOVE IN-LINE COMMENTS.
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
C  Fri Mar 31, 1989 14:37:15
C     CHANGE "SQRT" TO "DSQRT"
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC

C  THIS ROUTINE DOES A LINEAR LEAST-SQUARES FIT OF INPUT DATA.
C  INPUT: IX	- X VALUES IN DW INTEGERS; <0 => REJECTED POINT
C	  IY	- Y VALUES IN DW INTEGERS,
C	  NIN	- TOTAL NUMBER OF POINTS
C	  YDIV	- Y AXIS VALUE SCALING FACTOR (TO PRESERVE FRACTION)
C	  MODE   1=AVERAGE,
C		 2=LINEAR FIT,
C		 3=QUADRATIC FIT.
C  OUTPUT:A,B,C - COEFFICIENTS OF FIT: Y = A + B*X + B*X**2
C	  SD	- STANDARD DEVIATION OF FIT
C	  SE	- STANDARD ERROR OF FIT
C	  NIN	- NUMBER OF POINTS ACCEPTED
C	  NREJ	- NUMBER OF POINTS REJECTED
C
C  IF THE DETERMINATE=0., THE NEXT LOWER ORDER OF FIT IS USED
C	SX = SUM<X**I>, I->0,4
C	SYX = SUM<Y*X**I>, I->0,2
C
C  Revision History:
C	11/07/91 - Add sigma multiplier to argument list, and replace 
C	'3.0' below with the input value.  rlr
C
C$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ RLR 4/82

	character sccsid*(*)
	parameter (sccsid = "@(#)lsq.f	1.3\t01/06/92")
        PARAMETER (NWT = 5000)	! number of elements in wt (weight) array

	DIMENSION X(1),Y(1),SX(5),SYX(3)
	double precision skew, kurtosis, PmM, wt(1000), calc_pmm


C  ** INITIALIZE **
	skew= -1
	kurtosis= -1
	PmM= -1
	NREJ = 0
	DO 1 I=1,5
 1	SX(I) = 0.D0
	DO 2 I=1,3
 2	SYX(I) = 0.D0

	DO 10 II=1,NIN
	    IF (X(II) .LT. 0.D0) GO TO 9
	    DO 5 I=1,5
 5	    SX(I) = SX(I) + X(II)**(I-1)
	    DO 6 I=1,3
 6	    SYX(I) = SYX(I) + Y(II)*X(II)**(I-1)
	    GO TO 10

 9	    NREJ = NREJ+1
10	CONTINUE

20	GO TO (30,24,21) MODE

C  FORM: Y=A+BX+CX2
21	DET = SX(1)*(SX(3)*SX(5) - SX(4)*SX(4))
     X	    - SX(2)*(SX(2)*SX(5) - SX(3)*SX(4))
     X	    + SX(3)*(SX(2)*SX(4) - SX(3)*SX(3))
	IF (DET .EQ. 0.D0) GO TO 24
	A = (SYX(1) * (SX(3)*SX(5) - SX(4)*SX(4))
     X     - SYX(2) * (SX(2)*SX(5) - SX(3)*SX(4))
     X	   + SYX(3) * (SX(2)*SX(4) - SX(3)*SX(3)))/DET
	B =(-SYX(1) * (SX(2)*SX(5) - SX(3)*SX(4))
     X	   + SYX(2) * (SX(1)*SX(5) - SX(3)*SX(3))
     X	   - SYX(3) * (SX(1)*SX(4) - SX(2)*SX(3)))/DET
	C = (SYX(1) * (SX(2)*SX(4) - SX(3)*SX(3))
     X	   - SYX(2) * (SX(1)*SX(4) - SX(2)*SX(3))
     X	   + SYX(3) * (SX(1)*SX(3) - SX(2)*SX(2)))/DET
	GO TO 40

C  FORM: Y=A+BX
24	DET = SX(1)*SX(3) - SX(2)*SX(2)
	IF (DET .EQ. 0.D0) GO TO 30

	A = (SX(3)*SYX(1) - SX(2)*SYX(2))/DET
	B = (SX(1)*SYX(2) - SX(2)*SYX(1))/DET
	C = 0.D0
	GO TO 40

C  FORM: Y=A
30	A = SYX(1)/SX(1)
	B = 0.D0
	C = 0.D0
	TAVE = SX(2)/SX(1)

40	SV2 = 0.D0
	SV3 = 0.D0
	SV4 = 0.D0
	VMAX = 0.D0

C  FIND MAXIMUM RESIDUAL W.R.T. THE COEEFFICIENTS & FIND SUM OF ERRORS**2
	DO 50 II=1,NIN
C	Next test not general enough, but will work for llr. FIXME
	if (II .gt. NWT) go to 50
	wt(ii)= 0.d0
C		TOSS BAD POINT
	IF (X(II) .LT. 0.D0) GO TO 50
	wt(ii)= 1.d0
	YBAR = A + B*X(II) + C*X(II)**2
	V = Y(II) - YBAR
CX	TYPE YBAR,V  $$$ WILL PROBABLY CAUSE MAC SYS ERR W/O STRING ARG
	IF (ABS(V) .LT. ABS(VMAX)) GO TO 49
	    VMAX = V
	    NMAX = II
49	SV2 = SV2 + V*V
	SV3 = SV3 + V*V*V
	SV4 = SV4 + V*V*V*V
50	CONTINUE

	SD = 0.D0
	SE = 0.D0
	IF (SX(1) .GT. 1.1D0) then
	  SVAR= SV2/(SX(1)-1.D0)
	  SD = SQRT(SVAR)
	  SKEW= SV3 / ((SX(1)-1.D0) * SVAR * SD)
	  KURTOSIS= SV4 / ((SX(1)-1.D0) * SVAR * SVAR)- 3.D0
CC	  PmM= calc_pmm (Y, wt, SX(1), 1.d-3, YBAR)-  YBAR
	  PmM= calc_pmm (Y, wt, nin, 1.d-3, 0.d0)-  0.d0
CC	write(*,*) "stuff",svar,sd,skew,kurtosis,pmm
	ENDIF
	IF (SX(1) .GT. 0.1D0) SE = SD/SQRT(SX(1))
CX	TYPE "LINLSQ: SV2,SD,NIN,VMAX,NMAX,A,B,C"
CX	TYPE SV2,SD,NIN,VMAX,NMAX,A,B,C
	IF (NIN .LE. 2) GO TO 900
C		.LE. HANDLES VMAX=SD=0.
C	IF (ABS(VMAX) .LE. 3.D0*SD) GO TO 900
	IF (ABS(VMAX) .LE. sigmult*SD) GO TO 900

C  TOSS BAD POINT
	IF (SX(1) .LE. 3.1D0) GO TO 900
	NREJ = NREJ+1
	DO 55 I=1,5
 55	SX(I) = SX(I) - X(NMAX)**(I-1)
	DO 56 I=1,3
 56	SYX(I) = SYX(I) - Y(NMAX)*X(NMAX)**(I-1)

C  NEGATE TIME OF BAD POINT
	X(NMAX) = -X(NMAX)

	GO TO 20

900	NIN = NIN - NREJ
C
C	   THE
	   END
